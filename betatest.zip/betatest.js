document.addEventListener('DOMContentLoaded', function () {
    const profileContainer = document.querySelector('.profile-container');
    const secondaryCard = document.querySelector('.secondary-card');
    const tertiaryCard = document.querySelector('.tertiary-card');
    const bottomCard = document.querySelector('.bottom-card');
    const cards = [profileContainer, secondaryCard, tertiaryCard, bottomCard];

    cards.forEach(card => {
        card.addEventListener('mousemove', function (e) {
            const rect = card.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            const maxTilt = 15;
            const tiltX = (2 * mouseX / rect.width - 1) * maxTilt;
            const tiltY = -(2 * mouseY / rect.height - 1) * maxTilt;
            const rotateZ = 0; // Set rotateZ to 0 to prevent card rotation
            const perspectiveShift = Math.min(Math.sqrt((mouseX - rect.width / 2) ** 2 + (mouseY - rect.height / 2) ** 2) / 5, 200);

            card.style.transform = `perspective(1000px) rotateX(${tiltY}deg) rotateY(${tiltX}deg) rotateZ(${rotateZ}deg) translateZ(${perspectiveShift}px)`;
        });

        card.addEventListener('mouseleave', function () {
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) rotateZ(0deg)';
        });
    });

    const fourthCard = document.querySelector('.bottom-card');



    const logoContainer = document.createElement('div');
    logoContainer.classList.add('logo-container');

    logos.forEach((logo, index) => {
        const logoImg = document.createElement('img');
        logoImg.src = logo.src;
        logoImg.alt = logo.alt;
        logoImg.classList.add('logo');
        logoImg.style.position = 'absolute';
        logoImg.style.bottom = '5px';
        logoImg.style.left = `${50 + index * 100}px`; // Adjusted spacing
        logoImg.style.width = '40px';
        logoImg.style.height = 'auto';
        logoImg.style.filter = 'drop-shadow(0 0 5px white)';
        logoContainer.appendChild(logoImg);

        // Add hover effect
        logoImg.addEventListener('mouseenter', function () {
            logoImg.style.transform = 'scale(1.2)';
        });

        logoImg.addEventListener('mouseleave', function () {
            logoImg.style.transform = 'scale(1)';
        });
    });

    fourthCard.appendChild(logoContainer);
});
